/** Automatically generated file. DO NOT MODIFY */
package com.pda3505;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}