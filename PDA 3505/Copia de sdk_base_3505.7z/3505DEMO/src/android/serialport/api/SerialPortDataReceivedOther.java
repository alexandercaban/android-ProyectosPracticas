package android.serialport.api;

public interface SerialPortDataReceivedOther {
	public void onDataReceivedListener(final byte[] buffer, final int size); 

}
