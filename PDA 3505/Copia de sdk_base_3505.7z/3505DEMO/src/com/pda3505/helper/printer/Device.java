package com.pda3505.helper.printer;

public class Device {
	public String deviceName;
	public String deviceAddress;
}
